Code files:
main.ipynb - all of the code and results for my project. Results are towards the bottom.
data/* - images used in my code.

Name
Jerry Lai

SID
3031843855

email
thejerrylai@berkeley.edu

webpage
https://inst.eecs.berkeley.edu/~cs194-26/fa21/upload/files/proj2/cs194-26-ahu/jerry_proj2/