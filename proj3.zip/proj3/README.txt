JErry Lai
thejerrylai@berkeley.edu
3031843855

All code is in part1.ipynb, and in correct order.

Morph gif is in animation folder. All other images are in data folder.