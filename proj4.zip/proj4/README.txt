Email: thejerrylai@berkeley.edu

SID: 3031843855

Code:
All code to generate the lobby panorama is in proj.4_lobby.ipynb
All code to generate the roof panorama is in proj.4_roof.ipynb.

Both notebooks can be run independently, the cells can be run in order.

All images were taken by me.